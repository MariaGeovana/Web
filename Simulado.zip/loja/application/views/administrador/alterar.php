<div id="homebody">
    <div class="alinhado-centro borda-base espaco-vertical">
        <div class="row-fluid">
            <?php
            $atributos = array('name'=>'formuario_categoria','id'=>'formulario__categoria') ;
            echo form_open(base_url('crud/salvar_alteracao'),$atributos).
                form_hidden('id', $categorias[0]->id).
                form_label("Titulo:" ," txt_titulo") . br () .
                form_input('txt_titulo',$categorias[0]-> titulo).br ().
                form_label("Descrição:"," txt_des") . br () .
                form_input('txt_des',$categorias[0]-> descricao).br().
                form_submit("btn_enviar","Salvar Alteração").
                form_close () ;

            ?>
        </div>
    </div>
</div>

