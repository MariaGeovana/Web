<div id="homebody">
    <div class="alinhado-centro borda-base espaco-vertical">
    <div class="row-fluid">
			<?php
				$atributos = array( 'name '=> 'formulario_contato',
				'id '=> 'formulario_contato');
				echo form_open( base_url('home/enviar_mensagem') , $atributos) .
				form_label(" Nome :" ," txt_nome") . br () .
				form_input('txt_nome') . br () .
				form_label("E-mail:"," txt_email") . br () .
				form_input('txt_email') . br () .
				form_label(" Mensagem: "," txt_mensagem") . br () .
				form_textarea('txt_mensagem') . br () .
				form_submit(" btn_enviar"," Enviar Mensagem") .
				form_close () ;
			?>
 </div>
</div>