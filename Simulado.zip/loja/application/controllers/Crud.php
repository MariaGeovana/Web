<?php defined('BASEPATH') or exit('No direct script access allowed');

class Crud extends CI_Controller{

    private $categorias;

    public function __construct() {
        parent::__construct();
        $this->load->model('categorias_model', 'modelcategorias');
        $this->categorias = $this->modelcategorias->listar_categorias();
    }
    public function inserir(){
        $this->load->helper('form');
        $this->load->view('administrador/html-header');
        $this->load->view('administrador/header');
        $this->load->view('administrador/inserir');
        $this->load->view('administrador/html-footer');
        $this->load->view('administrador/footer');
        $this->load->view('administrador/html-footer');

    }
    public function adicionar(){
        $data['titulo']=$this->input->post('txt_titulo');
        $data['descricao']=$this->input->post('txt_des');
        if($this->db-> insert('categorias', $data)){
            redirect(base_url('cadastro_categorias'));
        }else{
            echo " Não foi possível gravar a postagem no banco de dados ";
        }
    }

    public function alterar($id){
        $this->db->where('id', $id);
        $data['categorias'] = $this->db->get('categorias')->result();
        $this->load->helper('form');
        $this->load->view('administrador/html-header');
        $this->load->view('administrador/header');
        $this->load->view('administrador/alterar',$data);
        $this->load->view('administrador/html-footer');
        $this->load->view('administrador/footer');
        $this->load->view('administrador/html-footer');
    }
    public function salvar_alteracao(){
        $data['titulo']=$this->input->post('txt_titulo');
        $data['descricao']=$this->input->post('txt_des');
        $this->db->where('id',$this->input->post('id'));
        if($this->db->update('categorias',$data)){
            redirect(base_url('cadastro_categorias'));
        }else{
            echo "Não foi possível gravar a ateração da postagemno banco de dados";
        }
    }
    public function remover($id){
        $this->db->where('categoria',$id);
        $cont = $this->db->get('produtos_categoria')->result();
        if(count($cont) == 0){
        if($this->db->delete('categorias', array('id'=>$id))){
            $this->load->helper('text');
            $data_header['categorias'] = $this->categorias;
            $this->load->view('administrador/html-header');
            $this->load->view('administrador/header');
            $this->load->view('administrador/mostrar_categoria',$data_header);
            $this->load->view('administrador/footer');
            $this->load->view('administrador/html-footer');
        }}
        else{
            echo "<script language='javascript'>
                alert('Não foi possivel excluir, essa categoria possuir produtos.');
                location.href=('http://localhost/loja/cadastro_categorias');
            </script>";
        }
    }
}
