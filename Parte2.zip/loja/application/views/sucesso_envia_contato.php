<div id="homebody">
    <div class="alinhado-centro borda-base espaco-vertical">
    	<div class="row-fluid">
		<?php
		echo anchor(base_url(),"Home").br();
		echo "E-mail enviado com sucesso!! "
		?>
	 	</div>
	</div>
</div>