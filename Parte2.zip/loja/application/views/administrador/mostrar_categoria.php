<div id="homebody">
    <div class="alinhado-centro borda-base espaco-vertical">
        <h3> Categorias </h3>
    </div>
    <div class="row-fluid">
        <div class="table-responsive">
            <?php
               echo "<table id='mytable' class='table table-bordred table-striped'><thead><th>Titulo</th><th>Descrição</th><th>Operações</th></thead><tbody>";
                foreach($categorias as $id) {
                echo "<tr><td>".$id->titulo."</td><td>".$id->descricao."</td><td>".
                anchor(base_url("crud/alterar/".$id->id),"Editar",array("class"=>"btn btn-warning")).
                anchor(base_url("crud/remover/".$id->id),"Excluir",array("class"=>"btn btn-medium btn-danger"));"</td></tr>";
            }
               echo "</tbody></table>";
            ?>
        <a id="button_inserir" class="btn btn-medium btn-primary" href="<?php echo base_url("crud/inserir")?>">Novo Item</a>
        </div>
    </div>
</div>
