<div id="homebody">
    <div class="alinhado-centro borda-base espaco-vertical">
        <h3> Produtos </h3>
    </div>
    <div class="row-fluid">
        <div class="table-responsive">
            <?php
               echo "<table id='mytable' class='table table-bordred table-striped'><thead><th>Código</th><th>Titulo</th><th>Descrição</th><th>Preço</th><th>Operações</th></thead><tbody>";
                foreach($produtos as $id){
                echo "<tr><td>".$id->codigo."</td><td>".$id->titulo."</td><td>".$id->descricao."</td><td>".$id->preco."</td><td>".
                anchor(base_url("crud/alterar_produtos/".$id->id),"Editar",array("class"=>"btn btn-warning")).
                anchor(base_url("crud/remover_produtos/".$id->id),"Excluir",array("class"=>"btn btn-medium btn-danger"));"</td></tr>";
            }
               echo "</tbody></table>";
            ?>
        <a id="button_inserir" class="btn btn-medium btn-primary" href="<?php echo base_url("crud/inserir_pro")?>">Novo Item</a>
        </div>
    </div>
</div>

