<div id="homebody">
    <div class="alinhado-esquerda borda-base espaco-vertical">
        <div class="row-fluid">
            <?php
            $atributos = array('name'=>'formuario_frete','id'=>'formulario__frete') ;
            echo form_open(base_url('crud/salvar_alteracao_frete'),$atributos).
                form_hidden('id', $frete[0]->id).

                form_label("Peso de:" ," txt_pesod") . br () .
                form_input('txt_pesod',$frete[0]-> peso_de).br ().

                form_label("Peso até:" ," txt_pesoa") . br () .
                form_input('txt_pesoa',$frete[0]-> peso_ate).br ().

                form_label("preço:"," txt_preco") . br () .
                form_input('txt_preco',$frete[0]-> preco).br().

                form_label("Adicional em kg:"," txt_adicional") . br () .
                form_input('txt_adicional',$frete[0]->adicional_kg).br().

                form_label("UF:"," txt_uf") . br () .
                form_input('txt_uf',$frete[0]->uf).br().

                form_submit("btn_enviar","Salvar Alteração").
                form_close () ;

            ?>
        </div>
    </div>
</div>



