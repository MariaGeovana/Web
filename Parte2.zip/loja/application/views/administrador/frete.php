<div id="homebody">
    <div class="alinhado-centro borda-base espaco-vertical">
        <h3> Fretes </h3>
    </div>
   <div class="row-fluid">
        <div class="table-responsive">
            <?php
               echo "<table id='mytable' class='table table-bordred table-striped'><thead><th>Peso de: </th><th>Peso até: </th><th>Preço: </th><th>Adicional em kg: </th><th>UF: </th></thead><tbody>";
                foreach($frete as $id){
                echo "<tr><td>".$id->peso_de."</td><td>".$id->peso_ate."</td><td>".$id->preco."</td><td>".$id->adicional_kg."</td><td>".$id->uf."</td><td>".
                anchor(base_url("crud/alterar_frete/".$id->id),"Editar",array("class"=>"btn btn-warning")).
                anchor(base_url("crud/remover_frete/".$id->id),"Excluir",array("class"=>"btn btn-medium btn-danger"));"</td></tr>";
            }
               echo "</tbody></table>";
            ?>
        <a id="button_inserir" class="btn btn-medium btn-primary" href="<?php echo base_url("crud/inserir_frete")?>">Novo Frete</a>
        </div>
    </div>
</div>

