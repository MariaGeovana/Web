<div id="homebody">
    <div class="alinhado-esquerda borda-base espaco-vertical">
        <div class="row-fluid">
            <?php
            $atributos = array('name'=>'formuario_frete','id'=>'formulario__frete') ;
            echo form_open(base_url('crud/adicionar_frete'),$atributos).

                form_label("Peso de:" ," txt_pesod") . br () .
                form_input('txt_pesod').br ().

                form_label("Peso até:" ," txt_pesoa") . br () .
                form_input('txt_pesoa').br ().

                form_label("preço:"," txt_preco") . br () .
                form_input('txt_preco').br().

                form_label("Adicional em kg:"," txt_adicional") . br () .
                form_input('txt_adicional').br().

                form_label("UF:"," txt_uf") . br () .
                form_input('txt_uf').br().

                form_submit("btn_enviar","Salvar Alteração").
                form_close () ;

            ?>
        </div>
    </div>
</div>




