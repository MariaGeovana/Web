<div id="homebody">
    <div class="alinhado-esquerda borda-base espaco-vertical">
        <div class="row-fluid">
            <?php
            $atributos = array('name'=>'formuario_inserir','id'=>'formulario__inserir') ;
            echo form_open(base_url('crud/adicionar_produtos'),$atributos).

                form_label("Codigos:" ," txt_codigo") . br () .
                form_input('txt_codigo').br ().

                form_label("Titulo:" ," txt_titulo") . br () .
                form_input('txt_titulo').br ().


                form_label("Descrição:"," txt_descricao") . br () .
                form_textarea('txt_descricao').br().

                form_label("Categorias:") . br ();
                foreach($categorias as $cat){
                    echo form_checkbox("categoria[]",$cat->id,false).
                    form_label($cat->titulo).br();
                }

                echo form_label("Preço:" ," txt_preco") . br () .
                form_input('txt_preco').br().


                form_label("Lagura da caixa em mm:"," txt_largura") . br () .
                form_input('txt_largura').br().

                form_label("Altura da caixa em mm:"," txt_altura") . br () .
                form_input('txt_altura').br().

                form_label("Comprimento da caixa em mm:"," txt_comprimento") . br () .
                form_input('txt_comprimento').br().

                form_label("peso em gramas:"," txt_peso") . br () .
                form_input('txt_peso').br().

                form_submit("btn_enviar","Inserir Registro").
                form_close () ;

            ?>
        </div>
    </div>
</div>
