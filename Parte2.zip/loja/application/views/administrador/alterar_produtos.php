<div id="homebody">
    <div class="alinhado-esquerda borda-base espaco-vertical">
        <div class="row-fluid">
            <?php
            $atributos = array('name'=>'formuario_produtos','id'=>'formulario__produtos') ;
            echo form_open(base_url('crud/salvar_alteracao_produtos'),$atributos).
                form_hidden('id', $produtos[0]->id).

                form_label("Codigos:" ," txt_codigo") . br () .
                form_input('txt_codigo',$produtos[0]-> codigo).br ().

                form_label("Titulo:" ," txt_titulo") . br () .
                form_input('txt_titulo',$produtos[0]-> titulo).br ().

                form_label("Descrição:"," txt_descricao") . br () .
                form_textarea('txt_descricao',$produtos[0]-> descricao).br().
                form_label("Categorias:") . br ();
            if(count($pro)!=0){
                foreach($categoria as $cats){
                    foreach($pro as $cat){
                        if($cats->id==$cat->categoria){
                            echo form_checkbox("categoria[]",$cats->id,true).
                            form_label($cats->titulo).br();
                            break;
                        }
                    }
                }
                foreach($categoria as $cats){
                    $a=true;
                    foreach($pro as $cat){
                        if($cats->id==$cat->categoria){
                            $a=false;
                            break;
                        }


                    }
                     if($a){
                            echo form_checkbox("categoria[]",$cats->id,false) .
                            form_label($cats->titulo).br();
                        }
                }
            }else{
                foreach($categoria as $cats){
                      echo form_checkbox("categoria[]",$cats->id,false).
                            form_label($cats->titulo).br();

                }
            }
                echo form_label("preço:"," txt_preco") . br () .
                form_input('txt_preco',$produtos[0]-> preco).br().

                form_label("Lagura da caixa em mm:"," txt_largura") . br () .
                form_input('txt_largura',$produtos[0]->largura_caixa_mm).br().

                form_label("Altura da caixa em mm:"," txt_altura") . br () .
                form_input('txt_altura',$produtos[0]->altura_caixa_mm).br().

                form_label("Comprimento da caixa em mm:"," txt_comprimento") . br () .
                form_input('txt_comprimento',$produtos[0]->comprimento_caixa_mm).br().

                form_label("peso em gramas:"," txt_peso") . br () .
                form_input('txt_peso',$produtos[0]-> peso_gramas).br().


                form_label("Ativo/Inativo(1/0):"," txt_status") . br () .
                form_input('txt_status',$produtos[0]->ativo).br().

                form_submit("btn_enviar","Salvar Alteração").
                form_close () ;

            ?>
        </div>
    </div>
</div>


