<div id="homebody">
    <div class="alinhado-centro borda-base espaco-vertical">
        <div class="row-fluid">
            <?php
            $atributos = array('name'=>'formuario_inserir','id'=>'formulario__inserir') ;
            echo form_open(base_url('crud/adicionar'),$atributos).
                form_label("Titulo:" ," txt_titulo") . br () .
                form_input('txt_titulo').br ().
                form_label("Descrição:"," txt_des") . br () .
                form_input('txt_des').br().
                form_submit("btn_enviar","Inserir").
                form_close () ;

            ?>
        </div>
    </div>
</div>


