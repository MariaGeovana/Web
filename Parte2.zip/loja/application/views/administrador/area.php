<div id="homebody">
    <div class="alinhado-centro borda-base espaco-vertical">
        <div class="row-fluid">
            <?php
                echo heading("Seja bem-vindo à área administrativa",2);
                echo heading("Aqui você poderá Incluir, Alterar ou Excluir registros nas tabelas de categorias, produtos ou frete.",5);
            ?>
            <hr>

            <a id="button_categorias" class="btn btn-medium btn-primary" href="<?php echo base_url("cadastro_categorias")?>">Cadastro de categorias</a>
            <a id="button_produtos"class="btn btn-medium btn-primary" href="<?php echo base_url("cadastro_produtos")?>">Cadastro de produtos</a>
            <a id="button_fretes"class="btn btn-medium btn-primary" href="<?php echo base_url("cadastro_frete")?>">Tabela de fretes</a>
        </div>
    </div>
</div>

