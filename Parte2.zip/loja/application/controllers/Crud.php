<?php defined('BASEPATH') or exit('No direct script access allowed');

class Crud extends CI_Controller{

    public $categorias;
    private $produtos;
    public $frete;

    public function __construct() {
        parent::__construct();
        $this->load->model('categorias_model', 'modelcategorias');
        $this->categorias = $this->modelcategorias->listar_categorias();
        $this->load->model('produtos_model', 'modelprodutos');
        $this->produtos = $this->modelprodutos->listar_produtos();
        $this->load->model('frete_model', 'modelfrete');
        $this->frete = $this->modelfrete->listar_frete();
    }
    public function inserir(){
        $this->load->helper('form');
        $this->load->view('administrador/html-header');
        $this->load->view('administrador/header');
        $this->load->view('administrador/inserir');
        $this->load->view('administrador/html-footer');
        $this->load->view('administrador/footer');
        $this->load->view('administrador/html-footer');

    }
    public function adicionar(){
        $data['titulo']=$this->input->post('txt_titulo');
        $data['descricao']=$this->input->post('txt_des');
        if($this->db-> insert('categorias', $data)){
            echo "<script language='javascript'>
                    alert('inserção ocorrida com sucesso.');
                    location.href=('http://localhost/loja/cadastro_categorias');
                    </script>";
        }else{
            echo "<script language='javascript'>
                    alert('Não foi possivel fazer a inserção.');
                    location.href=('http://localhost/loja/cadastro_categorias');
                    </script>";
        }
    }

    public function alterar($id){
        $this->db->where('id', $id);
        $data['categorias'] = $this->db->get('categorias')->result();
        $this->load->helper('form');
        $this->load->view('administrador/html-header');
        $this->load->view('administrador/header');
        $this->load->view('administrador/alterar',$data);
        $this->load->view('administrador/html-footer');
        $this->load->view('administrador/footer');
        $this->load->view('administrador/html-footer');
    }
    public function salvar_alteracao(){
        $data['titulo']=$this->input->post('txt_titulo');
        $data['descricao']=$this->input->post('txt_des');
        $this->db->where('id',$this->input->post('id'));
        if($this->db->update('categorias',$data)){
             echo "<script language='javascript'>
                    alert('Atualização ocorrida com sucesso.');
                    location.href=('http://localhost/loja/cadastro_categorias');
                    </script>";
        }else{
            echo "<script language='javascript'>
                    alert('Não foi possivel fazer a atualização.');
                    location.href=('http://localhost/loja/cadastro_categorias');
                    </script>";
        }
    }
    public function remover($id){
        $this->db->where('categoria',$id);
        $cont = $this->db->get('produtos_categoria')->result();
        if(count($cont) == 0){
            if($this->db->delete('categorias', array('id'=>$id))){
                echo "<script language='javascript'>
                    alert('exclusão ocorrida com sucesso.');
                    location.href=('http://localhost/loja/cadastro_categorias');
                    </script>";
            }
        }
        else{
            echo "<script language='javascript'>
                alert('Não foi possivel fazer a exclusão.');
                location.href=('http://localhost/loja/cadastro_categorias');
            </script>";
        }
    }
     public function alterar_produtos($id){
        $this->db->where('id', $id);
        $data['produtos'] = $this->db->get('produtos')->result();
        $data['categoria']= $this->modelcategorias->listar_categorias();
        $data['pc']= $this->db->get('produtos_categoria')->result();
        $this->db->where('produto', $id);
        $data['pro']= $this->db->get('produtos_categoria')->result();
        $this->load->helper('form');
        $this->load->view('administrador/html-header');
        $this->load->view('administrador/header');
        $this->load->view('administrador/alterar_produtos',$data);
        $this->load->view('administrador/html-footer');
        $this->load->view('administrador/footer');
        $this->load->view('administrador/html-footer');
    }

    public function salvar_alteracao_produtos(){
        $data['codigo']=$this->input->post('txt_codigo');
        $data['titulo']=$this->input->post('txt_titulo');
        $data['descricao']=$this->input->post('txt_descricao');
        $data['preco']=$this->input->post('txt_preco');
        $data['largura_caixa_mm']=$this->input->post('txt_largura');
        $data['altura_caixa_mm']=$this->input->post('txt_altura');
        $data['comprimento_caixa_mm']=$this->input->post('txt_comprimento');
        $data['peso_gramas']=$this->input->post('txt_peso');
        $dados=$this->input->get_post('categoria[]');
        $a=$data['codigo'];
        $e;
         $this->db->where('id',$this->input->post('id'));
        if($this->db->update('produtos', $data)){
            $e=true;
        }else{
            $e=false;
            }
        $this->db->where('codigo',$this->input->post('txt_codigo'));
        $d=$this->db->get('produtos')->result();
        $this->db->where('produto',$d[0]->id);
        $this->db->delete('produtos_categoria');
        foreach($dados as $b){
            $c['produto']=$d[0]->id;
            $c['categoria']=$b;
            $this->db->insert('produtos_categoria',$c);
        }
        if($e){
            echo "Produto alterado com sucesso ";
        }
            redirect(base_url('cadastro_produtos'));
    }
    public function remover_produtos($id){
        $this->db->where('produto',$id);
        if($this->db->delete('produtos_categoria')){
            $this->db->where('id',$id);
            if($this->db->delete('produtos')){
                echo "<script language='javascript'>
                alert('Produto excluido com sucesso.');
                location.href=('http://localhost/loja/cadastro_produtos');
                </script>";
            }else{
                echo "<script language='javascript'>
                alert('Não foi possivel excluir.');
                location.href=('http://localhost/loja/cadastro_produtos');
                </script>";
            }
        }else{
            echo "<script language='javascript'>
            alert('Não foi possivel excluir, essa categoria possuir produtos.');
            location.href=('http://localhost/loja/cadastro_produtos');
            </script>";
        }
    }
        public function inserir_pro(){
        $dados['categorias']=$this->db->get('categorias')->result();
        $this->load->helper('form');
        $this->load->view('administrador/html-header');
        $this->load->view('administrador/header');
        $this->load->view('administrador/inserir_produtos',$dados);
        $this->load->view('administrador/html-footer');
        $this->load->view('administrador/footer');
        $this->load->view('administrador/html-footer');

    }
        public function adicionar_produtos(){
        $data['codigo']=$this->input->post('txt_codigo');
        $data['titulo']=$this->input->post('txt_titulo');
        $data['descricao']=$this->input->post('txt_descricao');
        $data['preco']=$this->input->post('txt_preco');
        $data['largura_caixa_mm']=$this->input->post('txt_largura');
        $data['altura_caixa_mm']=$this->input->post('txt_altura');
        $data['comprimento_caixa_mm']=$this->input->post('txt_comprimento');
        $data['peso_gramas']=$this->input->post('txt_peso');
        $dados=$this->input->get_post('categoria[]');
        $a=$data['codigo'];
        $e;
        if($this->db->insert('produtos', $data)){
            $e=true;
        }else{
            $e=false;
            }
        $this->db->where('codigo',$this->input->post('txt_codigo'));
        $d=$this->db->get('produtos')->result();

        foreach($dados as $b){
            $c['produto']=$d[0]->id;
            $c['categoria']=$b;
            $this->db->insert('produtos_categoria',$c);
        }
        if($e){
            echo "Produto inserido com sucesso ";
        }
            redirect(base_url('cadastro_produtos'));
    }
    public function inserir_frete(){
        $this->load->helper('form');
        $this->load->view('administrador/html-header');
        $this->load->view('administrador/header');
        $this->load->view('administrador/inserir_frete');
        $this->load->view('administrador/html-footer');
        $this->load->view('administrador/footer');
        $this->load->view('administrador/html-footer');

    }
    public function adicionar_frete(){
        $data['peso_de']=$this->input->post('txt_pesod');
        $data['peso_ate']=$this->input->post('txt_pesoa');
        $data['preco']=$this->input->post('txt_preco');
        $data['adicional_kg']=$this->input->post('txt_adicional');
        $data['uf']=$this->input->post('txt_uf');
        if($this->db-> insert('tb_transporte_preco', $data)){
            echo "<script language='javascript'>
            alert('Inserção ocorrida com sucesso.');
            location.href=('http://localhost/loja/cadastro_frete');
            </script>";
        }else{
            echo "<script language='javascript'>
            alert('Não foi possivel fazer a inserção.');
            location.href=('http://localhost/loja/cadastro_frete');
            </script>";
        }
    }
    public function alterar_frete($id){
        $this->db->where('id', $id);
        $data['frete'] = $this->db->get('tb_transporte_preco')->result();
        $this->load->helper('form');
        $this->load->view('administrador/html-header');
        $this->load->view('administrador/header');
        $this->load->view('administrador/alterar_frete',$data);
        $this->load->view('administrador/html-footer');
        $this->load->view('administrador/footer');
        $this->load->view('administrador/html-footer');
    }
    public function salvar_alteracao_frete(){
       $data['peso_de']=$this->input->post('txt_pesod');
        $data['peso_ate']=$this->input->post('txt_pesoa');
        $data['preco']=$this->input->post('txt_preco');
        $data['adicional_kg']=$this->input->post('txt_adicional');
        $data['uf']=$this->input->post('txt_uf');
        $this->db->where('id',$this->input->post('id'));
        if($this->db->update('tb_transporte_preco',$data)){
            echo "<script language='javascript'>
            alert('Atualização ocorrida com sucesso.');
            location.href=('http://localhost/loja/cadastro_frete');
            </script>";
        }else{
            echo "<script language='javascript'>
            alert('Não foi possivel fazer a atualização.');
            location.href=('http://localhost/loja/cadastro_frete');
            </script>";
        }
    }

    public function remover_frete($id){
        $this->db->where('id',$id);
        if($this->db->delete('tb_transporte_preco')){
            echo "<script language='javascript'>
            alert('Frete excluido com sucesso.');
            location.href=('http://localhost/loja/cadastro_frete');
            </script>";
        }
    }
}
