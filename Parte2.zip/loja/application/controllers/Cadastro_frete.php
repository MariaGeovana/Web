<?php
    defined('BASEPATH') OR exit('No direct script access allowed');
    class Cadastro_frete extends CI_Controller{
        public $frete;

        public function __construct(){
            parent::__construct();
            $this->load->model('frete_model', 'modelfrete');
            $this->frete = $this->modelfrete->listar_frete();
        }

        public function index(){
            $this->load->helper('text');
            $data_header['frete'] = $this->frete;
            $this->load->view('administrador/html-header');
            $this->load->view('administrador/header');
            $this->load->view('administrador/frete',$data_header);
            $this->load->view('administrador/footer');
            $this->load->view('administrador/html-footer');
        }

}

