<?php
    defined('BASEPATH') OR exit('No direct script access allowed');
    class Cadastro_produtos extends CI_Controller{
        public $produtos;

        public function __construct(){
            parent::__construct();
            $this->load->model('categorias_model','modelcategorias');
            $this->load->model('produtos_model','modelprodutos');
            $this->produtos = $this->modelprodutos->listar_produtos();
        }

        public function index(){
            $this->load->helper('text');
            $data_header['produtos'] = $this->produtos;
            $this->load->view('administrador/html-header');
            $this->load->view('administrador/header');
            $this->load->view('administrador/mostrar_produtos',$data_header);
            $this->load->view('administrador/footer');
            $this->load->view('administrador/html-footer');
        }

}
