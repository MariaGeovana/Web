<?php
    defined('BASEPATH') OR exit('No direct script access allowed');
    class Cadastro_categorias extends CI_Controller{
        public $categorias;

        public function __construct(){
            parent::__construct();
            $this->load->model('categorias_model','modelcategorias');
            $this->load->model('produtos_model','modelprodutos');
            $this->categorias = $this->modelcategorias->listar_categorias();
        }

        public function index(){
            $this->load->helper('text');
            $data_header['categorias'] = $this->categorias;
            $this->load->view('administrador/html-header');
            $this->load->view('administrador/header');
            $this->load->view('administrador/mostrar_categoria',$data_header);
            $this->load->view('administrador/footer');
            $this->load->view('administrador/html-footer');
        }
    }
