<?php defined('BASEPATH') OR exit('No direct script access allowed');
    class Frete_model extends CI_Model {
        public function __construct(){
            parent::__construct();
        }
        
        public function detalhes_frete($id) {
            $this->db->where('id',$id);
            return $this->db->get('tb_transporte_preco')->result();
        }
        public function listar_frete(){
            $this->db->order_by('uf','ASC');
            return $this->db->get('tb_transporte_preco')->result();
        }           
    }       

